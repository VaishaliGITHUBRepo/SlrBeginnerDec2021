class Hello{
	//commandline argument
	public static void main(String[] args){
		System.out.println(args[0]);
		System.out.println("Hello World");
	}
}