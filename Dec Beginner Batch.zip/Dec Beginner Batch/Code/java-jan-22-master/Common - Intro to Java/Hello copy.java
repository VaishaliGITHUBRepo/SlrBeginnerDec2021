package com.january;

public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello this is a Java Class");
    }
}
