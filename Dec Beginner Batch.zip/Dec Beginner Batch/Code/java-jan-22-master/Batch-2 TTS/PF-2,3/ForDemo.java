package com.jan2;

public class ForDemo {

    public static void main(String[] args) {
        int i=1;
        for(  ;i<=5; ){
            System.out.println(i);
            i++;
        }
        System.out.println("After "+i);
        
        /* Multiline 
        comment
        */
        /*
        for(i=1; i<=5; i++){
            System.out.println(i);
        }
        System.out.println("After "+i); 
        */

        // Single line Comment

    }
}
