package com.january;

public class ForLoopDemo {

    public static void main(String[] args) {

        int cal =0;

        for( ;cal<=5 ;cal+=2){
            System.out.println(cal);
        }
        System.out.println("After Loop " + cal);



    }


}
