package com.january;

public class LoopsDemo {

    public static void main(String[] args) {

        int i = 1;
        while(i<=5){
            i = i + 1;
        }
        System.out.println(i);

        /*
        int cal = 0;
        int steps = 0;
        while(cal<100){
            steps = steps + 1;
            System.out.println("Running "+steps);
            cal = cal + 5;
        }
         */

    }
}
