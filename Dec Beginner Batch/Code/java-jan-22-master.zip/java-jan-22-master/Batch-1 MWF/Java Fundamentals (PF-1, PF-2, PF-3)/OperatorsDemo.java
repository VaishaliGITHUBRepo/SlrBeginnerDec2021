package com.january;

public class OperatorsDemo {

    public static void main(String[] args) {

        int x = 10;
        int y = x++;
        System.out.println(x +","+y);
        y = ++x;
        System.out.println(x + ","+y);

    }
}
