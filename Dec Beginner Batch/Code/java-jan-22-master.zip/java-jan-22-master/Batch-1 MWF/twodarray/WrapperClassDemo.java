package com.january.twodarray;

public class WrapperClassDemo {
    public static void main(String[] args) {

        int x = 5;
        Integer y = 5; //Integer is wrapper class
        y.toString();
        y.shortValue();



    }
}
